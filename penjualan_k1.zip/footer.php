<section class="footer">

    <div class="box-container">

        <div class="box">
            <h3>Tautan cepat</h3>
            <a href="home.php">home</a>
            <a href="about.php">Tentang</a>
            <a href="contact.php">Kontak</a>
            <a href="shop.php">Belanja</a>
        </div>

        <div class="box">
            <h3>Tautan tambahan</h3>
            <a href="login.php">login</a>
            <a href="register.php">Daftar</a>
            <a href="orders.php">Pesanan </a>
            <a href="cart.php">Keranjang </a>
        </div>

        <div class="box">
            <h3>Info kontak</h3>
            <p> <i class="fas fa-phone"></i> 0857-8080-6575 </p>
            <p> <i class="fas fa-phone"></i> 0866-6969-9090 </p>
            <p> <i class="fas fa-envelope"></i> snackpu@gmail.com </p>
            <p> <i class="fas fa-map-marker-alt"></i> indonesia-sumatera utara</p>
        </div>

        <div class="box">
            <h3>Ikuti akun kami</h3>
            <a href="#"><i class="fab fa-facebook-f"></i>facebook</a>
            <a href="#"><i class="fab fa-twitter"></i>twitter</a>
            <a href="#"><i class="fab fa-instagram"></i>instagram</a>
            <a href="#"><i class="fab fa-linkedin"></i>linkedin</a>
        </div>

    </div>

</section>