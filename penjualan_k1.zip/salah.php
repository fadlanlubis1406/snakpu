<?php
// Mendefinisikan array satu dimensi
$angka = array(1, 2, 3, 4, 5);

// Menampilkan isi array
foreach ($angka as $nilai) {
    echo $nilai . " ";
}
?>
