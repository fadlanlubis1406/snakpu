<?php
// Mendefinisikan array awal
$data = array(1, 2, 3);

// Menambahkan elemen baru ke array
array_push($data, 4);

// Menampilkan isi array setelah penambahan
foreach ($data as $nilai) {
    echo $nilai . " ";
}
?>
